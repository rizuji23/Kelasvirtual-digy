var express = require('express');
var router = express.Router();
var bodyParser = require('body-parser');
var formidable = require('formidable');
var path = require('path');
var fs = require('fs-extra');